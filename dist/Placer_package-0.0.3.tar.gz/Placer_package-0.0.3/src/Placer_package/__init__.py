__author__ = "Placer084"
__license__ = "CC BY-NC-SA 4.0"


__all__ = ['ether', 'games', 'shortr']
