# Placer_package
## *Modules written by Placer_0884*



### The package currently contains:
- Shortr  - Basic input formating
- Games   - Module for games, currently holds saveable highscore creation and usage function
- Ether   - Unrecognized input logger, used to log unrecognized inputs into a ether_logs.txt file


### License:
**Attribution-NonCommercial-ShareAlike 4.0 International (CC BY-NC-SA 4.0)**